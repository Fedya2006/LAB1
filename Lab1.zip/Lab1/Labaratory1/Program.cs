﻿using System;
using System.Collections.Generic;
using System.Numerics;

namespace Labaratory1
{
    delegate Vector2 Fv2Vector2(Vector2 v2);
    static class Calc
    {
        public static Vector2 Calc1(Vector2 v2)
        {
            Vector2 res = new Vector2();
            res.X = v2.X + v2.Y;
            res.Y = v2.X - v2.Y;
            return res;
        }
        public static Vector2 Calc2(Vector2 v2)
        {
            Vector2 res = new Vector2();
            res.X = v2.X * v2.Y;
            res.Y = v2.X / v2.Y;
            return res;
        }
    }
    abstract class V4Data
    {
        public string Name { get; }
        public DateTime Time { get; }

        public V4Data()
        {
            
        }
        
        public V4Data(string str, DateTime time)
        {
            Name = str;
            Time = time;
        }
        
        abstract public int Count { get; }
        
        abstract public float MaxFromOrigin { get; }

        abstract public string ToLongString(string format);

        public override string ToString()
        {
            return Name + " " + Time;
        }
    }
    struct DataItem
    {
        public DataItem(Vector2 coord, Vector2 fld)
        {
            Coordinates = coord;
            Field = fld;
        }
        public Vector2 Coordinates { get; set; }
        public Vector2 Field { get; set; }

        public string ToLongString(string format)
        {
            return "Coordinates - " + Coordinates.ToString(format) + "\nVector values - " +
                   Field.ToString(format) + "\nAbs - " + Field.Length().ToString(format) + "\n";
        }

        public override string ToString()
        {
            return $"Type -DataItem\nX - {Coordinates.X}\nY - {Coordinates.Y}\nField1 - {Field.X}\nField1 - {Field.Y}";
        }
    }
    class V4DataList : V4Data
    {
        public List<DataItem> List { get; set; }

        public V4DataList(string Str, DateTime Time): base(Str, Time)
        {
            List = new List<DataItem>();
        }

        private bool Find(List<DataItem> src, ref DataItem Item)
        {
            for (int i = 0; i < List.Count; i++)
                if (List[i].Coordinates.X == Item.Coordinates.X && List[i].Coordinates.Y == Item.Coordinates.Y)
                    return true;
            return false;
        }
        
        public bool Add(DataItem newItem)
        {
            if (!Find(List, ref newItem))
            {
                List.Add(newItem);
                return true;
            }
            else
                return false;
        }

        public int AddDefaults(int nItems, Fv2Vector2 F)
        {
            int sum = 0;
            Random rnd = new Random();
            for (int i = 0; i < nItems; i++)
            {
                float x = rnd.Next();
                float y = rnd.Next();
                Vector2 coordinates = new Vector2(x, y);
                Vector2 result = F(coordinates);
                DataItem newItem = new DataItem(coordinates, result);
                if (Add(newItem))
                    sum++;
            }
            return sum;
        }

        public override int Count
        {
            get
            {
                return List.Count;
            }
        }

        public override float MaxFromOrigin
        {
            get
            {
                float max = -1;
                foreach (DataItem i in List)
                {
                    float dist = i.Coordinates.Length();
                    
                    if (dist > max)
                        max = dist;
                }
                return max;
            }
        }

        public override string ToString()
        {
            return
                $"Type - V4DataList\nBase class info: String - {Name}, Date - {Time}\nNumber of elements - {List.Count}";
        }

        public override string ToLongString(string format)
        {
            string sum = $"Type - V4DataList\nBase class info: String - {Name}, Date - {Time}\nNumber of elements - {List.Count}\n";
            foreach (DataItem i in List)
                sum += i.ToLongString(format) + "______________________________________\n";
            return sum;
        }
    }
    class V4DataArray : V4Data
    {
        public int numberX { get; set; }
        
        public int numberY { get; set; }
        
        public Vector2 steps { get; set; }
        public Vector2[,] values { get; }
        
        public V4DataArray(string Str, DateTime Time): base(Str, Time)
        {
            values = new Vector2[0,0];
        }

        public V4DataArray(string Str, DateTime Time, int numX, int numY, Vector2 step, Fv2Vector2 F):
            base(Str, Time)
        {
            Vector2 coord = new Vector2();
            coord.X = 0;
            coord.Y = 0;
            values = new Vector2[numY, numX];
            for(int i = 0; i < numY; i++)
                for (int j = 0; j < numX; j++)
                {
                    coord.X += step.X;
                    coord.Y += step.Y;
                    values[i, j] = F(coord);
                }
            steps = step;
            numberX = numX;
            numberY = numY;
        }

        public override int Count
        {
            get
            {
                return numberX * numberY;
            }
        }

        public override float MaxFromOrigin
        {
            get
            {
                if ((numberX > 0) && (numberY > 0))
                {
                    Vector2 v1 = new Vector2((numberX - 1) * steps.X, (numberY - 1) * steps.Y);
                    return v1.Length();
                }
                return -1;
            }
        }

        public override string ToString()
        {
            return $"V4DataArray\nName - {Name}\nDate - {Time}\nNumber of nodes on the x axis - {numberX}\nNumber of nodes on the y axis - {numberY}\n";
        }

        public override string ToLongString(string format)
        {
            string sum = $"V4DataArray\nName - {Name}\nDate - {Time}\nNumber of nodes on the x axis - {numberX}\nNumber of nodes on the y axis - {numberY}\n";
            for (int i = 0; i < numberY; i++)
            {
                sum += '\n';
                for (int j = 0; j < numberX; j++)
                {
                    sum +=
                        $"X - {j * steps.X}\nY - {i * steps.Y}\nField - " 
                            + values[i, j].ToString(format) + "\nModule - " + values[i,j].Length().ToString(format) 
                        + "\n______________________________________\n";
                }    
            }
            return sum;
        }
        public static implicit operator V4DataList (V4DataArray ar)
        {
            
            V4DataList res = new V4DataList(ar.Name, ar.Time);
            for (int i = 0; i < ar.numberY; i++)
                for (int j = 0; j < ar.numberX; j++)
                {
                    Vector2 temp_vec = new Vector2();
                    temp_vec.X = j * ar.steps.X;
                    temp_vec.Y = i * ar.steps.Y;
                    DataItem temp = new DataItem(temp_vec, ar.values[i,j]);
                    res.List.Add(temp);
                }
            return res;
        }
    }
    
    class V4MainCollection
    {
        private List<V4Data> data;

        public V4MainCollection()
        {
            data = new List<V4Data>();
        }
        public int Count
        {
            get
            {
                return data.Count;
            }
        }

        public V4Data this[int i]
        {
            get
            {
                return data[i];
            }
        }

        public bool Contains(string id)
        {
            if (data.Count == 0)
                return false;
            foreach (V4Data temp in data)
            {
                if (temp.Name == id)
                    return true;
            }

            return false;
        }

        public bool Add(V4Data v4Data)
        {
            if (!Contains(v4Data.Name))
            {
                data.Add(v4Data);
                return true;
            }
            else
                return false;
        }

        public string ToLongString(string format)
        {
            string sum = "";
            foreach (V4Data temp in data)
            {
                sum = sum +  temp.ToLongString(format) + "\n";
            }
            return sum;
        }
        
        public override string ToString()
        {
            string sum = "";
            foreach (V4Data temp in data)
            {
                sum = sum +  temp.ToString() + "\n";
            }
            return sum;
        }
        
    }
    
    class Program
    {
        static void Main(string[] args)
        {
            //Задание 1
            Vector2 step = new Vector2(1, 2);
            V4DataArray temp1 = new V4DataArray("node1", DateTime.Now, 3, 3, step, Calc.Calc1);
            Console.WriteLine(temp1.ToLongString("F2"));
            V4DataList temp2 = temp1;
            Console.WriteLine(temp2.ToLongString("F2"));
            Console.WriteLine(temp1.Count);
            Console.WriteLine(temp1.MaxFromOrigin);
            Console.WriteLine(temp2.Count);
            Console.WriteLine(temp2.MaxFromOrigin);

            //Задание 2
            V4DataArray temp3 = new V4DataArray("node2", DateTime.Now, 4, 2, step, Calc.Calc2);
            V4DataArray temp4 = new V4DataArray("node3", DateTime.Now, 1, 3, step, Calc.Calc1);
            V4MainCollection collection = new V4MainCollection();
            collection.Add(temp2);
            collection.Add(temp3);
            collection.Add(temp4);  
            Console.WriteLine(collection.ToLongString("F2"));
           
            //Задание 3
            int n = collection.Count;
            for(int i = 0; i < n; i++)
            {
                Console.WriteLine(collection[i].Name);
                string s = "Count: " + collection.Count.ToString() + "\nMaxdist: " + collection[i].MaxFromOrigin.ToString();
                Console.WriteLine(s);
                Console.WriteLine("\n");
            }
        }
    }
}